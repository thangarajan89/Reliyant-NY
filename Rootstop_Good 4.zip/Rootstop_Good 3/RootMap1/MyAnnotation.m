//
//  MyAnnotation.m
//  Reliant NY
//
//  Created by Dheeraj Deevi on 23/09/13.
//  Copyright (c) 2013 Kalyan. All rights reserved.
//

#import "MyAnnotation.h"

@implementation MyAnnotation
@synthesize title;
@synthesize subtitle;
@synthesize coordinate;

@end
