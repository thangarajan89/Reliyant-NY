//
//  NextStopsViewController.m
//  RootMap1
//
//  Created by K@ly@n on 08/09/13.
//  Copyright (c) 2013 Kalyan. All rights reserved.
//

#import "NextStopsViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "ViewController.h"

#import "MBReachability.h"
#import "MyAnnotation.h"
@interface NextStopsViewController ()

@end

@implementation NextStopsViewController

bool Check_Uncmleted;
bool Notstarted=NO;
bool started=NO;

@synthesize bus_stop_view, showaddress_btn_name, rootName, rootID ,banner1,lat_ary,long_ary,webData,sign_off_btn,back_btn1,refresh_btn,map_Btn,BusId,BusId1,Status_arr;


@synthesize geomapView,cords_long,cords_lat,title_ary,mapView,change_view,bus_num,depo_status,dir_ary,routeLine,RedrouteLine,map_tab_showing;
@synthesize busData;

bool Sview;
bool CheckComplete=NO;
bool ShowGreen=NO;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    bus_stop_view.hidden=NO;
    map_tab_showing.hidden=YES;

}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    stopClose_arr=[[NSMutableArray alloc]init];
    
    Time_arr=[[NSMutableArray alloc]init];
    Time2_arr=[[NSMutableArray alloc]init];
    Status_arr=[[NSMutableArray alloc]init];
    NextStop_arr=[[NSMutableArray alloc]init];
    est_status_arr1=[[NSMutableArray alloc]init];
    est_status_arr2=[[NSMutableArray alloc]init];
    
    lat_ary=[[NSMutableArray alloc]init];
    long_ary=[[NSMutableArray alloc]init];
    
    VehicleId_arr=[[NSMutableArray alloc]init];
    Direction_arr=[[NSMutableArray alloc]init];
    DirectionId_arr=[[NSMutableArray alloc]init];
   
    
    TripDirection_arr=[[NSMutableArray alloc]init];
    TripDirectionId_arr=[[NSMutableArray alloc]init];
    TripLatt_arr=[[NSMutableArray alloc]init];
    TripLon_arr=[[NSMutableArray alloc]init];
    TripMDCid_arr=[[NSMutableArray alloc]init];
    TripTitle_arr=[[NSMutableArray alloc]init];
    
    new_string=[[NSString alloc]init];
    route_pass=[[NSString alloc]init];
    
    route_pass=route_page.row_num;
    [showaddress_btn_name setTitle:rootName forState:UIControlStateNormal];
    
    ScreenWidth=[UIScreen mainScreen].bounds.size.width;
    ScreenHeight=[UIScreen mainScreen].bounds.size.height;
    
    NSLog(@"Status is %d",ScreenWidth);
    NSLog(@"Status is %d",ScreenHeight);

    [tablView setFrame:CGRectMake(10, 131, ScreenWidth-20,ScreenHeight-161)];
    tablView.layer.cornerRadius=10;
    //[self.view addSubview:tablView];
    
    if ([MBReachability hasConnectivity])
    {
        [act setFrame:CGRectMake(135, 260, 50, 50)];
        [act startAnimating];
        [self.view addSubview:act];
        [self InterActionEnabledView];
        loadingStops=@"Yes";
        [self getdata];
        //[self normaldata];
    
    }else{
        alert5= [[UIAlertView alloc]initWithTitle:@"No internet connectivity!"  message:@"Please try later" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert5 show];
    }

//    map_tab_showing.hidden=YES;
//    bus_stop_view.hidden=NO;
    
    // Mapview Objects
    LastLatitude_arr=[[NSMutableArray alloc]init];
    LastLongitude_arr=[[NSMutableArray alloc]init];
    cords_lat=[[NSMutableArray alloc]init];
    cords_long=[[NSMutableArray alloc]init];
    title_ary=[[NSMutableArray alloc]init];
    _path=[[NSMutableArray alloc]init];
    showTitle=[[NSMutableArray alloc]init];
    UnComl_lat=[[NSMutableArray alloc]init];
    UnComl_lon=[[NSMutableArray alloc]init];
    UnComl_title=[[NSMutableArray alloc]init];
    

}

-(void)getdata
{
    started=NO;
    Notstarted=NO;
    
    [back_btn1 setEnabled:NO];
    [sign_off_btn setEnabled:NO];
    [refresh_btn setEnabled:NO];
    [map_Btn setEnabled:NO];
    [showaddress_btn_name setEnabled:NO];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://otpstaging.timepointsoftware.com/api/MobileAPI/GetBlockByRouteId?dbId=450.1&RouteId=%@&includeIncidents=true&includeStopInfo=true", rootID]]];
    [request setHTTPMethod:@"GET"];
    [request setValue:@"application/xml;charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    
    NSString *accept = [NSString stringWithFormat:@"application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5"];
    
    [request addValue:accept forHTTPHeaderField: @"Accept"];
    NSURLConnection *conn = [NSURLConnection connectionWithRequest:request delegate:self];
    [conn start];
    if(conn)
        webData = [NSMutableData data];
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDic
{
    currentElement = elementName;
    
    if ([loadingStops isEqualToString:@"no"]) {
        if ([currentElement isEqualToString:@"LastLatitude"])
        {
            NSDictionary *myAttrDict = [[NSDictionary alloc] initWithDictionary:attributeDic];
            if([[myAttrDict objectForKey:@"i:nil"] isEqualToString:@"true"])
            {
                [LastLatitude_arr addObject:@""];
            }
            
        }
        if ([currentElement isEqualToString:@"LastLongitude"])
        {
            NSDictionary *myAttrDict = [[NSDictionary alloc] initWithDictionary:attributeDic];
            if([[myAttrDict objectForKey:@"i:nil"] isEqualToString:@"true"])
            {
                [LastLongitude_arr addObject:@""];
            }
            
        }

    }else{
        if ([currentElement isEqualToString:@"ScheduledTimeString"])
        {
            NSDictionary *myAttrDict = [[NSDictionary alloc] initWithDictionary:attributeDic];
            if([[myAttrDict objectForKey:@"i:nil"] isEqualToString:@"true"])
            {
                [Time_arr addObject:@""];
            }
        }
        if ([currentElement isEqualToString:@"ArriveTime"])
        {
            NSDictionary *myAttrDict = [[NSDictionary alloc] initWithDictionary:attributeDic];
            if([[myAttrDict objectForKey:@"i:nil"] isEqualToString:@"true"])
            {
                [est_status_arr1 addObject:@""];
            }
            
        }
        if ([currentElement isEqualToString:@"Address1"])
        {
            new_string=@"";
        }
        if ([currentElement isEqualToString:@"EstimatedTime"])
        {
            NSDictionary *myAttrDict = [[NSDictionary alloc] initWithDictionary:attributeDic];
            if([[myAttrDict objectForKey:@"i:nil"] isEqualToString:@"true"])
            {
                [est_status_arr2 addObject:@""];
            }
            
        }
        
        if([currentElement isEqualToString:@"Latitude"])
        {
            NSDictionary *myAttrDict = [[NSDictionary alloc] initWithDictionary:attributeDic];
            if([[myAttrDict objectForKey:@"i:nil"] isEqualToString:@"true"])
            {
                return;
            }
        }
        if([currentElement isEqualToString:@"Longitude"])
        {
            NSDictionary *myAttrDict = [[NSDictionary alloc] initWithDictionary:attributeDic];
            if([[myAttrDict objectForKey:@"i:nil"] isEqualToString:@"true"])
            {
                return;
            }
        }
        if ([currentElement isEqualToString:@"MDCID"])
        {
            NSDictionary *myAttrDict = [[NSDictionary alloc] initWithDictionary:attributeDic];
            if([[myAttrDict objectForKey:@"i:nil"] isEqualToString:@"true"])
            {
                [Status_arr addObject:@""];
            }
            
        }
        
        if ([currentElement isEqualToString:@"VehicleId"])
        {
            NSDictionary *myAttrDict = [[NSDictionary alloc] initWithDictionary:attributeDic];
            if([[myAttrDict objectForKey:@"i:nil"] isEqualToString:@"true"])
            {
                [VehicleId_arr addObject:@""];
            }
        }
        if ([currentElement isEqualToString:@"Direction"])
        {
            NSDictionary *myAttrDict = [[NSDictionary alloc] initWithDictionary:attributeDic];
            if([[myAttrDict objectForKey:@"i:nil"] isEqualToString:@"true"])
            {
                [Direction_arr addObject:@""];
            }
            
        }
        if ([currentElement isEqualToString:@"DirectionId"])
        {
            NSDictionary *myAttrDict = [[NSDictionary alloc] initWithDictionary:attributeDic];
            if([[myAttrDict objectForKey:@"i:nil"] isEqualToString:@"true"])
            {
                [DirectionId_arr addObject:@""];
            }
            
        }

    }

}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if ([loadingStops isEqualToString:@"no"])
    {
        if ([currentElement isEqualToString:@"LastLatitude"])
        {
            if([string isEqualToString:@"NA"])
            {
                string=@"";
            }
            [LastLatitude_arr addObject:string];
        }
        if ([currentElement isEqualToString:@"LastLongitude"])
        {
            if([string isEqualToString:@"NA"])
            {
                string=@"";
            }
            [LastLongitude_arr addObject:string];
        }
        //NSLog(@"%@,%@",LastLongitude_arr,LastLongitude_arr);
    }
    else
    {
        if ([currentElement isEqualToString:@"Address1"])
        {
            
            if(string.length >0)
            {
                new_string=[new_string stringByAppendingString:string];
            }
            
            // NSLog(@"%@",new_string);
            
        }
        if ([currentElement isEqualToString:@"ScheduledTimeString"])
        {
            if (string==nil) {
                string=@"";
            }
            [Time_arr addObject:string];
        }
        if ([currentElement isEqualToString:@"ArriveTime"])
        {
            if([string isEqualToString:@"NA"])
            {
                string=@"";
            }
            NSArray *listItems = [string componentsSeparatedByString:@"T"];
            [est_status_arr1 addObject:listItems[1]];
        }
        if ([currentElement isEqualToString:@"EstimatedTime"])
        {
            if([string isEqualToString:@"NA"])
            {
                string=@"";
            }
            NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
            //2013-09-19T05:30:00
            dateFormatter.dateFormat = @"yyyy'-'MM'-'dd'T'HH:mm:sss";
            NSDate* serverDate = [dateFormatter dateFromString:string];
            // NSLog(@"%@",serverDate);
            [dateFormatter setDateFormat:@"h:mm a"];
            NSString *datestr=[dateFormatter stringFromDate:serverDate];
            //  NSLog(@"%@",datestr);
            if (datestr==nil) {
                datestr=@"";
            }
            [est_status_arr2 addObject:datestr];
        }
        if([currentElement isEqualToString:@"MDCID"])
        {
            if([string isEqualToString:@"NA"])
            {
                string=@"";
            }
            [Status_arr addObject:string];
        }
        if([currentElement isEqualToString:@"Latitude"])
        {
            //        if(![lat_ary containsObject:string])
            //        {
            //            [lat_ary addObject:string];
            //        }
            [lat_ary addObject:string];
        }
        if([currentElement isEqualToString:@"Longitude"])
        {
            
            //        if(![long_ary containsObject:string])
            //        {
            //            [long_ary addObject:string];
            //        }
            [long_ary addObject:string];
        }
        
        
        if ([currentElement isEqualToString:@"VehicleId"])
        {
            if([string isEqualToString:@"NA"])
            {
                string=@"";
            }
            if(![VehicleId_arr containsObject:string])
            {
                [VehicleId_arr addObject:string];
            }
        }
        if ([currentElement isEqualToString:@"Direction"])
        {
            if([string isEqualToString:@"NA"])
            {
                string=@"";
            }
            [Direction_arr addObject:string];
        }
        if ([currentElement isEqualToString:@"DirectionId"])
        {
            if([string isEqualToString:@"NA"])
            {
                string=@"";
            }
            [DirectionId_arr addObject:string];
        }
    }
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if ([loadingStops isEqualToString:@"Yes"])
    {
        if ([currentElement isEqualToString:@"Address1"])
        {
            if (new_string==nil) {
                new_string=@"";
            }
            [NextStop_arr addObject:new_string];
        }
    }
}
- (void)parserDidEndDocument:(NSXMLParser *)parser {
    
    if ([loadingStops isEqualToString:@"no"])
    {
        
        [self performSelector:@selector(loadMap) withObject:self afterDelay:1.0];
        
    }
    else
    {
        [tablView reloadData];
//        [act stopAnimating];
//        [act setHidesWhenStopped:YES];
        
        
        if(NextStop_arr.count==0)
        {
            [self HideView];
            alert_NoRecords=[[UIAlertView alloc]initWithTitle:Nil message:@"Records Not Found" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
            [alert_NoRecords show];
        }else{
            [self UpdateArrays];
        }
        
        if (tablView.hidden==YES) {
            [self performSelector:@selector(mapcalling) withObject:self afterDelay:0.5];
        }
        
        banner1.hidden=YES;
    }
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    NSLog(@"%d,%d,%d,%d,%d",Status_arr.count,est_status_arr1.count,est_status_arr2.count,NextStop_arr.count,Time_arr.count);
    return NextStop_arr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    for (UIView * view in cell.contentView.subviews)
    {
        [view removeFromSuperview];
    }
    if ([est_status_arr2 count] == 0)
    {
        [Time2_arr addObjectsFromArray:est_status_arr1];//  NSLog(@"Arrived Time");
    }else{
        [Time2_arr addObjectsFromArray:est_status_arr2];//  NSLog(@"Estimated Time");
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
           
    UILabel *lbl1=[[UILabel alloc]initWithFrame:CGRectMake(150, 0, 1, 44)];
    lbl1.backgroundColor=[UIColor whiteColor];
    [cell addSubview:lbl1];
    
    UILabel *lbl2=[[UILabel alloc]initWithFrame:CGRectMake(230, 0, 1, 44)];
    lbl2.backgroundColor=[UIColor whiteColor];
    [cell addSubview:lbl2];

    UIView *viewleft=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 150, 42)];
    viewleft.backgroundColor=[UIColor lightGrayColor];
        
    UILabel *NextStop=[[UILabel alloc]initWithFrame:CGRectMake(7, 0, 140, 42)];
    NextStop.backgroundColor=[UIColor clearColor];
    
    NextStop.textColor=[UIColor whiteColor];
    NextStop.numberOfLines=2;
    NextStop.text=[NSString stringWithFormat:@"%@",[NextStop_arr objectAtIndex:indexPath.row]];
    NextStop.textAlignment=NSTextAlignmentLeft;
    NextStop.font=[UIFont boldSystemFontOfSize:14];
        
    [viewleft addSubview:NextStop];


    [cell addSubview:viewleft];
    
    UILabel *Sheduled=[[UILabel alloc]initWithFrame:CGRectMake(152, 0, 78, 42)];
    Sheduled.backgroundColor=[UIColor colorWithRed:170/255.0 green:170/255.0 blue:170/255.0 alpha:1];
     Sheduled.textColor=[UIColor whiteColor];
    Sheduled.text=[NSString stringWithFormat:@"%@   ",[Time_arr objectAtIndex:indexPath.row]];
    Sheduled.textAlignment=NSTextAlignmentRight;
    Sheduled.font=[UIFont boldSystemFontOfSize:14];

    [cell addSubview:Sheduled];
    
    UILabel *Estimated=[[UILabel alloc]initWithFrame:CGRectMake(232, 0,72, 42)];
    Estimated.backgroundColor=[UIColor colorWithRed:170/255.0 green:170/255.0 blue:170/255.0 alpha:1];
     Estimated.textColor=[UIColor whiteColor];
    Estimated.text=[NSString stringWithFormat:@"%@  ",[Time2_arr objectAtIndex:indexPath.row]];
    Estimated.textAlignment=NSTextAlignmentRight;
    Estimated.font=[UIFont boldSystemFontOfSize:14];

    [cell addSubview:Estimated];
    
    if([Status_arr[indexPath.row] isEqualToString:@""])
    {
        viewleft.backgroundColor=[UIColor lightGrayColor];
        Sheduled.backgroundColor=[UIColor lightGrayColor];
        Estimated.backgroundColor=[UIColor lightGrayColor];
    }else{
        //view.backgroundColor=[UIColor colorWithRed:85/255.0 green:85/255.0 blue:85/255.0 alpha:1];
        viewleft.backgroundColor=[UIColor colorWithRed:85/255.0 green:85/255.0 blue:85/255.0 alpha:1];
        Sheduled.backgroundColor=[UIColor colorWithRed:85/255.0 green:85/255.0 blue:85/255.0 alpha:1];
        Estimated.backgroundColor=[UIColor colorWithRed:85/255.0 green:85/255.0 blue:85/255.0 alpha:1];
    }


       return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 44;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.001;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    view.backgroundColor=[UIColor colorWithRed:33/255.0 green:162/255.0 blue:220/255.0 alpha:1];
    
    UILabel *lbl1=[[UILabel alloc]initWithFrame:CGRectMake(150, 0, 1, 44)];
    lbl1.backgroundColor=[UIColor whiteColor];
    [view addSubview:lbl1];
    
    UILabel *lbl2=[[UILabel alloc]initWithFrame:CGRectMake(230, 0, 1, 44)];
    lbl2.backgroundColor=[UIColor whiteColor];
    [view addSubview:lbl2];
    
    UILabel *NextStop=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 156, 44)];
    NextStop.backgroundColor=[UIColor clearColor];
    NextStop.text=@"Stops  ";
    NextStop.textAlignment=NSTextAlignmentCenter;
    NextStop.font=[UIFont boldSystemFontOfSize:14];
    NextStop.textColor=[UIColor whiteColor];
    [view addSubview:NextStop];
    
    UILabel *Sheduled=[[UILabel alloc]initWithFrame:CGRectMake(152, 0, 78, 44)];
    Sheduled.backgroundColor=[UIColor clearColor];
    Sheduled.text=@"Scheduled";
    Sheduled.textColor=[UIColor whiteColor];
    Sheduled.textAlignment=NSTextAlignmentCenter;
    Sheduled.font=[UIFont boldSystemFontOfSize:14];
    [view addSubview:Sheduled];
    
    UILabel *Estimated=[[UILabel alloc]initWithFrame:CGRectMake(228, 0, 78, 44)];
    Estimated.backgroundColor=[UIColor clearColor];
    Estimated.text=@"Estimated";
    Estimated.textColor=[UIColor whiteColor];
    Estimated.textAlignment=NSTextAlignmentCenter;
    Estimated.font=[UIFont boldSystemFontOfSize:14];
    [view addSubview:Estimated];

    return view;
}
// Called after the user changes the selection.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{}
-(IBAction)Back:(id)sender
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
-(void)normaldata
{
    NSString *path=[[NSBundle mainBundle]pathForResource:@"GetBlockByRouteId_1.1" ofType:@"xml"];
    NSURL *url=[NSURL fileURLWithPath:path];
    NSData *data=[NSData dataWithContentsOfURL:url];
    xmlParser = [[NSXMLParser alloc] initWithData:data];
    [xmlParser setDelegate:self];
    [xmlParser setShouldResolveExternalEntities:YES];
    [xmlParser setShouldProcessNamespaces:YES];
    [xmlParser parse];
}
- (IBAction)refresh_btn:(id)sender
{
        [NextStop_arr removeAllObjects];
        [Time_arr removeAllObjects];
        [Time2_arr removeAllObjects];
        [Direction_arr removeAllObjects];
        [DirectionId_arr removeAllObjects];
        [stopClose_arr removeAllObjects];
        [stopClose_arr removeAllObjects];
        [dict removeAllObjects];
        [TripDirection_arr removeAllObjects];
        [TripDirectionId_arr removeAllObjects];
        [TripLatt_arr removeAllObjects];
        [TripLon_arr removeAllObjects];
        [TripMDCid_arr removeAllObjects];
        [TripTitle_arr removeAllObjects];
        [est_status_arr1 removeAllObjects];
        [est_status_arr2 removeAllObjects];
        [lat_ary removeAllObjects];
        [long_ary removeAllObjects];
        [Status_arr removeAllObjects];
        [stopClose_arr removeAllObjects];
        [VehicleId_arr removeAllObjects];
    
    [tablView reloadData];
    started=NO;
    Notstarted=NO;
    loadingStops=@"Yes";
    //[act startAnimating];
    [self InterActionEnabledView];
    [self performSelector:@selector(getdata) withObject:self afterDelay:0.5 ];
    //[self performSelector:@selector(normaldata) withObject:self afterDelay:0.5 ];
    
    
    
    // [self mapcalling];
   // [self ActivityView];
    
//    NSString *path=[[NSBundle mainBundle]pathForResource:@"GetBlockByRouteId_new2" ofType:@"xml"];
//    NSURL *url=[NSURL fileURLWithPath:path];
//    NSData *data=[NSData dataWithContentsOfURL:url];
//    xmlParser = [[NSXMLParser alloc] initWithData:data];
//    [xmlParser setDelegate:self];
//    [xmlParser setShouldResolveExternalEntities:YES];
//    [xmlParser setShouldProcessNamespaces:YES];
//    [xmlParser parse];

}

- (IBAction)bus_stop_btn:(id)sender
{
    tablView.hidden=NO;
    maplet.hidden=YES;
}
- (IBAction)exit_btn:(id)sender
{
    alert2=[[UIAlertView alloc]initWithTitle:Nil message:@"Are you sure to exit?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
    [alert2 show];

}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView == alert_NoRecords)
    {
        if (buttonIndex == 0)
        {
             NSLog(@"alert clicked");
            [self.navigationController popToRootViewControllerAnimated:YES];
            
        }
    }
    if(alertView == alert2)
    {
        if (buttonIndex == 0)
        {
            ;
        }
        else
        {
          exit(0);
        }
    }
    if(alertView == alert5)
    {
        if (buttonIndex == 0)
        {
            [act stopAnimating];
             [self.navigationController popToRootViewControllerAnimated:YES];
        }
    }
}
-(void)UpdateArrays{
    
    NSLog(@"GOLD:%@",[VehicleId_arr objectAtIndex:0]);
    BusId1=[NSString stringWithFormat:@"%@",VehicleId_arr[0]];
    
    dict=[[NSMutableDictionary alloc]init];
    
    if ([BusId1 isEqualToString:@""])
    {
        UIAlertView *alertv= [[UIAlertView alloc]initWithTitle:nil  message:@"Map data not yet Ready" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alertv show];
        
    }
    else
    {
        for(int i=0;i<Status_arr.count;i++)
        {
            if (i==0) {
                ;
            }else{
                if ([[Status_arr objectAtIndex:i] isEqualToString:@""]) {
                    
                    if ([[NextStop_arr objectAtIndex:1] isEqualToString:[NextStop_arr objectAtIndex:i]]) {
                        if (started==NO) {
                            [TripDirection_arr addObject:[Direction_arr objectAtIndex:i]];
                            [TripDirectionId_arr addObject:[DirectionId_arr objectAtIndex:i]];
                            [TripLatt_arr addObject:[lat_ary objectAtIndex:i]];
                            [TripLon_arr addObject:[long_ary objectAtIndex:i]];
                            [TripTitle_arr addObject:[NextStop_arr objectAtIndex:i]];
                            [TripMDCid_arr addObject:[Status_arr objectAtIndex:i]];
                        }else{
                            Notstarted=YES;
                        }
                    }else{
                        if (Notstarted==NO) {
                            [TripDirection_arr addObject:[Direction_arr objectAtIndex:i]];
                            [TripDirectionId_arr addObject:[DirectionId_arr objectAtIndex:i]];
                            [TripLatt_arr addObject:[lat_ary objectAtIndex:i]];
                            [TripLon_arr addObject:[long_ary objectAtIndex:i]];
                            [TripTitle_arr addObject:[NextStop_arr objectAtIndex:i]];
                            [TripMDCid_arr addObject:[Status_arr objectAtIndex:i]];
                            started = YES;
                        }
                    }

                }else{
                    if ([[NextStop_arr objectAtIndex:1] isEqualToString:[NextStop_arr objectAtIndex:i]]) {
                        if (TripTitle_arr.count>0) {
                            [TripDirection_arr removeAllObjects];
                            [TripDirectionId_arr removeAllObjects];
                            [TripLatt_arr removeAllObjects];
                            [TripLon_arr removeAllObjects];
                            [TripTitle_arr removeAllObjects];
                            [TripMDCid_arr removeAllObjects];
                        }
                        [TripDirection_arr addObject:[Direction_arr objectAtIndex:i]];
                        [TripDirectionId_arr addObject:[DirectionId_arr objectAtIndex:i]];
                        [TripLatt_arr addObject:[lat_ary objectAtIndex:i]];
                        [TripLon_arr addObject:[long_ary objectAtIndex:i]];
                        [TripTitle_arr addObject:[NextStop_arr objectAtIndex:i]];
                        [TripMDCid_arr addObject:[Status_arr objectAtIndex:i]];
                    }else{
                        [TripDirection_arr addObject:[Direction_arr objectAtIndex:i]];
                        [TripDirectionId_arr addObject:[DirectionId_arr objectAtIndex:i]];
                        [TripLatt_arr addObject:[lat_ary objectAtIndex:i]];
                        [TripLon_arr addObject:[long_ary objectAtIndex:i]];
                        [TripTitle_arr addObject:[NextStop_arr objectAtIndex:i]];
                        [TripMDCid_arr addObject:[Status_arr objectAtIndex:i]];
                    }

                }
                
            }
            
        }
        
        NSLog(@"%d ,%d ,%d ,%d ,%d ,%d",TripDirection_arr.count,TripDirectionId_arr.count,TripTitle_arr.count,TripLatt_arr.count,TripLon_arr.count,TripMDCid_arr.count);
        
        NSLog(@"status:%@ Ttitle:%@ DirectionId:%@",TripMDCid_arr,TripTitle_arr,TripDirectionId_arr);
        
        [dict setObject:TripDirectionId_arr forKey:@"DirectionId"];
        [dict setObject:TripDirection_arr forKey:@"Direction"];
        [dict setObject:TripLatt_arr forKey:@"Lat"];
        [dict setObject:TripLon_arr forKey:@"Lon"];
        [dict setObject:TripMDCid_arr forKey:@"MDCID"];
        [dict setObject:TripTitle_arr forKey:@"Title"];             
    }

    if (tablView.hidden==NO) {
        [self HideView];
    }
 
}
- (IBAction)map_Btn:(id)sender
{
    maplet.hidden=NO;
    tablView.hidden=YES;
    
    maplet.layer.cornerRadius=10;
    maplet.backgroundColor=[UIColor redColor];
    maplet.frame=CGRectMake(10, 131, 300,ScreenHeight-161);
    [self.view addSubview:maplet];
    
    mapView.layer.cornerRadius=10;
    
    [self InterActionEnabledView];
    
    [self performSelector:@selector(mapcalling) withObject:self afterDelay:0.5 ];

}
-(void)mapcalling
{
    [LastLatitude_arr removeAllObjects];
    [LastLongitude_arr removeAllObjects];

    [self mapwillappear];
    [self mapdidloading];
    [self mapdidappear];
}
-(void)mapwillappear
{
    
    //NSLog(@"%@",title_ary);
//    [act setFrame:CGRectMake(135, 260, 50, 50)];
//    [act startAnimating];
//    [self.view addSubview:act];
    
//    if (tablView.hidden==NO) {
//         [self InterActionEnabledView];
//    }
   
    
    [LastLongitude_arr removeAllObjects];
    [LastLatitude_arr removeAllObjects];
    [cords_lat removeAllObjects];
    [cords_long removeAllObjects];
    [title_ary removeAllObjects];
    [_path removeAllObjects];
    [UnComl_lat removeAllObjects];
    [UnComl_lon removeAllObjects];
    [UnComl_title removeAllObjects];


    loadingStops=@"no";
    [self getbusdata];
//    NSString *path=[[NSBundle mainBundle]pathForResource:@"GetVehicle_1.1" ofType:@"xml"];
//    NSURL *url=[NSURL fileURLWithPath:path];
//    NSData *data=[NSData dataWithContentsOfURL:url];
//    xmlParser = [[NSXMLParser alloc] initWithData:data];
//    [xmlParser setDelegate:self];
//    [xmlParser setShouldResolveExternalEntities:YES];
//    [xmlParser setShouldProcessNamespaces:YES];
//    [xmlParser parse];
    
}
-(void)mapdidappear{
    
    direction=[dict objectForKey:@"Direction"];
    NSArray *directionId=[dict objectForKey:@"DirectionId"];
    NSArray *Lat=[dict objectForKey:@"Lat"];
    NSArray *Lon=[dict objectForKey:@"Lon"];
    NSArray *Mdcid=[dict objectForKey:@"MDCID"];
    NSArray *titl=[dict objectForKey:@"Title"];
    
    NSLog(@"%d %d %d %d %d %d",Mdcid.count,Lat.count,titl.count,directionId.count,Lon.count,direction.count);
    
    NSLog(@"%@ %@",Lon,Lat);
    
    if ([[direction objectAtIndex:0] isEqualToString:@"Loop"]) {
        
        for (int k=0; k<Mdcid.count; k++) {
            if ([[Mdcid objectAtIndex:k] isEqualToString:@""]) {
                [UnComl_lat addObject:[Lat objectAtIndex:k]];
                [UnComl_lon addObject:[Lon objectAtIndex:k]];
                [UnComl_title addObject:[titl objectAtIndex:k]];
            }
        }
        cords_lat=[NSMutableArray arrayWithArray:Lat];
        cords_long=[NSMutableArray arrayWithArray:Lon];
        title_ary=[NSMutableArray arrayWithArray:titl];
    }else{
        int index;
        if ([[Mdcid objectAtIndex:Mdcid.count-1] isEqualToString:@""]) {
            index=[Mdcid indexOfObject:@""];
        }else{
            index=[Mdcid indexOfObject:[Mdcid objectAtIndex:Mdcid.count-1]];
        }
        // int index=[Mdcid indexOfObject:@""];
        NSLog(@"%d %@",index,[directionId objectAtIndex:index]);
        
        if ([[directionId objectAtIndex:index] isEqualToString:@"1"]) {
            for (int m=0; m<directionId.count; m++) {
                
                if ([[directionId objectAtIndex:m] isEqualToString:@"1"]) {
                    
                    if ([[Mdcid objectAtIndex:m] isEqualToString:@""]) {
                        [UnComl_lat addObject:[Lat objectAtIndex:m]];
                        [UnComl_lon addObject:[Lon objectAtIndex:m]];
                        [UnComl_title addObject:[titl objectAtIndex:m]];
                    }
                    [cords_lat addObject:[Lat objectAtIndex:m]];
                    [cords_long addObject:[Lon objectAtIndex:m]];
                    [title_ary addObject:[titl objectAtIndex:m]];
                    
                }
            }
            
        }else{
            for (int m=0; m<directionId.count; m++) {
                if ([[directionId objectAtIndex:m] isEqualToString:@"2"]) {
                    if ([[Mdcid objectAtIndex:m] isEqualToString:@""]) {
                        [UnComl_lat addObject:[Lat objectAtIndex:m]];
                        [UnComl_lon addObject:[Lon objectAtIndex:m]];
                        [UnComl_title addObject:[titl objectAtIndex:m]];
                    }
                    
                    [cords_lat addObject:[Lat objectAtIndex:m]];
                    [cords_long addObject:[Lon objectAtIndex:m]];
                    [title_ary addObject:[titl objectAtIndex:m]];
                }
            }
            
        }
        
    }
    
    NSLog(@"%d %d %d %d",UnComl_title.count,cords_lat.count,cords_long.count,title_ary.count);
    NSLog(@"%@ %@ %@ %@",UnComl_title,title_ary,cords_lat,cords_long);
    
 }
- (void)mapdidloading {

    Sview =YES;
    [change_view setTitle:@"Satilite View" forState:UIControlStateNormal];
    mapView.MapType =MKMapTypeStandard;
       
}


-(void)loadMap{
	
    mapView.delegate=self;
    CLLocation *userLoc = mapView.userLocation.location;
    CLLocationCoordinate2D userCoordinate = userLoc.coordinate;
	
    //NSLog(@"user latitude = %f",userCoordinate.latitude);
    //NSLog(@"user longitude = %f",userCoordinate.longitude);
    annotations=[[NSMutableArray alloc] init];
    [annotations removeAllObjects];
    
    for(int i=0;i<cords_lat.count;i++)
    {
        CLLocationCoordinate2D theCoordinate1;
        theCoordinate1.latitude = [[cords_lat objectAtIndex:i] floatValue];
        theCoordinate1.longitude = [[cords_long objectAtIndex:i] floatValue];
        
        MyAnnotation* myAnnotation1=[[MyAnnotation alloc] init];
        myAnnotation1.coordinate=theCoordinate1;
        myAnnotation1.title=[title_ary objectAtIndex:i];
        [mapView addAnnotation:myAnnotation1];
        [annotations addObject:myAnnotation1];
    }
    // Adding BUS Location
    CLLocationCoordinate2D theCoordinate1;
    theCoordinate1.latitude = [[LastLatitude_arr objectAtIndex:0] floatValue];
    theCoordinate1.longitude = [[LastLongitude_arr objectAtIndex:0] floatValue];
    MyAnnotation* myAnnotation1=[[MyAnnotation alloc] init];
    
    myAnnotation1.coordinate=theCoordinate1;
    
    myAnnotation1.title=[NSString stringWithFormat:@"%f",[[LastLatitude_arr objectAtIndex:0] floatValue]];
    // myAnnotation1.subtitle=@"in the city";
    
    [mapView addAnnotation:myAnnotation1];
    [annotations addObject:myAnnotation1];
    
	//NSLog(@"%d",[annotations count]);
    MKMapRect flyTo = MKMapRectNull;
	for (id <MKAnnotation> annotation in annotations) {
        //	NSLog(@"fly to on");
        MKMapPoint annotationPoint = MKMapPointForCoordinate(annotation.coordinate);
        MKMapRect pointRect = MKMapRectMake(annotationPoint.x, annotationPoint.y, 0, 0);
        if (MKMapRectIsNull(flyTo)) {
            flyTo = pointRect;
        } else {
            flyTo = MKMapRectUnion(flyTo, pointRect);
			//NSLog(@"else-%@",annotationPoint.x);
        }
    }
    mapView.visibleMapRect = flyTo;
     [showTitle removeAllObjects];
    
    for (int i=0; i<cords_lat.count-1; i++) {
        if ([UnComl_lat containsObject:[cords_lat objectAtIndex:i]]) {
            ;
        }else{
            [self updateRouteView:[cords_lat objectAtIndex:i+1] firstlon:[cords_long objectAtIndex:i+1] secondlat:[cords_lat objectAtIndex:i] secondLon:[cords_long objectAtIndex:i]];
            
        }
    }
    ShowGreen=YES;
    [self LoadLine];
    [showTitle removeAllObjects];
    
    if (UnComl_lon.count>1) {
        for (int i=0; i<UnComl_lat.count-1; i++) {
            [self updateRouteView:[UnComl_lat objectAtIndex:i+1] firstlon:[UnComl_lon objectAtIndex:i+1] secondlat:[UnComl_lat objectAtIndex:i] secondLon:[UnComl_lon objectAtIndex:i]];
        }
        
        [self LoadLine];
    }
    
    
}
-(void)InterActionEnabledView{
    InterActionview=[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    InterActionview.backgroundColor=[UIColor darkGrayColor];
    [InterActionview setAlpha:0.25];
    [self.view addSubview:InterActionview];
    
    [act setFrame:CGRectMake(135, 260, 50, 50)];
    [act startAnimating];
    [self.view addSubview:act];
}
-(void)HideView{
    [InterActionview removeFromSuperview];
    [act stopAnimating];
    [act removeFromSuperview];
}
-(void)LoadLine{
    
    CLLocationManager * locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate=self;
    [locationManager startUpdatingLocation];
    
    CLLocation *location1 = [locationManager location];
    CLLocationCoordinate2D coordinate = [location1 coordinate];
    
    NSString *str=[[NSString alloc] initWithFormat:@" latitude:%f longitude:%f",coordinate.latitude,coordinate.longitude];
    NSLog(@"%@",str);
	//NSArray* pointStrings=[self calculateRoutesFrom:coordinate to:coordinate];
	
	// while we create the route points, we will also be calculating the bounding box of our route
	// so we can easily zoom in on it.
	MKMapPoint northEastPoint;
	MKMapPoint southWestPoint;
	
	// create a c array of points.
	MKMapPoint* pointArr = malloc(sizeof(CLLocationCoordinate2D) * _path.count);
	
	for(int idx = 0; idx < _path.count; idx++)
	{
		// break the string down even further to latitude and longitude fields.
		NSString* currentPointString = [_path objectAtIndex:idx];
        NSLog(@"%@",currentPointString);
		NSArray* latLonArr = [currentPointString componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
        
		CLLocationDegrees latitude  = [[latLonArr objectAtIndex:0] doubleValue];
		CLLocationDegrees longitude = [[latLonArr objectAtIndex:1] doubleValue];
        
        
		// create our coordinate and add it to the correct spot in the array
		CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        
		MKMapPoint point = MKMapPointForCoordinate(coordinate);
        
		
		//
		// adjust the bounding box
		//
		
		// if it is the first point, just use them, since we have nothing to compare to yet.
		if (idx == 0) {
			northEastPoint = point;
			southWestPoint = point;
		}
		else
		{
			if (point.x > northEastPoint.x)
				northEastPoint.x = point.x;
			if(point.y > northEastPoint.y)
				northEastPoint.y = point.y;
			if (point.x < southWestPoint.x)
				southWestPoint.x = point.x;
			if (point.y < southWestPoint.y)
				southWestPoint.y = point.y;
		}
        
		pointArr[idx] = point;
        
	}
    // create the polyline based on the array of points.
    self.routeLine = [MKPolyline polylineWithPoints:pointArr count:_path.count];
    if (ShowGreen==YES) {
        ShowGreen=NO;
        [self.routeLine setTitle:@"typeA"];
    }else{
        
        [self.routeLine setTitle:@"typeB"];
    }
    
    _routeRect = MKMapRectMake(southWestPoint.x, southWestPoint.y, northEastPoint.x - southWestPoint.x, northEastPoint.y - southWestPoint.y);
    [mapView addOverlay:self.routeLine];
    
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView1 viewForAnnotation:(id <MKAnnotation>)annotation
{
	//NSLog(@"welcome into the map view annotation");
	
	// if it's the user location, just return nil.
    if ([annotation isKindOfClass:[MKUserLocation class]])
        return nil;
    
	// try to dequeue an existing pin view first
	static NSString* AnnotationIdentifier = @"AnnotationIdentifier";
	MKPinAnnotationView* pinView = [[MKPinAnnotationView alloc]
                                    initWithAnnotation:annotation reuseIdentifier:AnnotationIdentifier];
	pinView.animatesDrop=YES;
	pinView.canShowCallout=YES;
	pinView.pinColor=MKPinAnnotationColorPurple;
	
	
	UIButton* rightButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
	[rightButton setTitle:annotation.title forState:UIControlStateNormal];
	[rightButton addTarget:self
					action:@selector(showDetails:)
		  forControlEvents:UIControlEventTouchUpInside];
	pinView.rightCalloutAccessoryView = rightButton;
	
	UIImageView *profileIconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"profile.png"]];
	pinView.leftCalloutAccessoryView = profileIconView;
	
    pinView = nil;
    if(annotation != mapView1.userLocation)
    {
        static NSString *defaultPinID = @"com.invasivecode.pin";
        pinView = (MKPinAnnotationView *)[mapView1 dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
        if ( pinView == nil )
            pinView = [[MKPinAnnotationView alloc]
                       initWithAnnotation:annotation reuseIdentifier:defaultPinID];
        
        //pinView.pinColor = MKPinAnnotationColorGreen;
        pinView.canShowCallout = YES;
        //pinView.animatesDrop = YES;
        if([annotation.title isEqualToString:[NSString stringWithFormat:@"%f",[[LastLatitude_arr objectAtIndex:0] floatValue]]])
        {
            pinView.pinColor = MKPinAnnotationColorPurple;
            //pinView.image = [UIImage imageNamed:@"bus1.png"];
        }
        else
        {
            if ([UnComl_title containsObject:annotation.title])
            {
                pinView.pinColor = MKPinAnnotationColorRed;
            }else{
                
                pinView.pinColor = MKPinAnnotationColorGreen;
            }
            // pinView.pinColor = MKPinAnnotationColorRed;
            
        }
    }
    else
    {
        [mapView1.userLocation setTitle:@"I am here"];
    }
	[act stopAnimating];
    [act setHidesWhenStopped:YES];
	return pinView;
}


-(void)getbusdata
{
    NSLog(@"%@",bus_num);
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://otpstaging.timepointsoftware.com/api/MobileAPI/GetVehicle?dbId=450.1&VehicleId=%@",BusId1]]];
    [request setHTTPMethod:@"GET"];
    [request setValue:@"application/xml;charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    
    NSString *accept = [NSString stringWithFormat:@"application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5"];
    
    [request addValue:accept forHTTPHeaderField: @"Accept"];
    NSURLConnection *conn = [NSURLConnection connectionWithRequest:request delegate:self];
    [conn start];
    if(conn)
        busData = [NSMutableData data];
}
- (IBAction)change_view:(id)sender {
    if(Sview==NO)
    {
        Sview=YES;
        [change_view setTitle:@"Satellite View" forState:UIControlStateNormal];
        mapView.MapType =MKMapTypeStandard;
    }
    else
    {
        Sview=NO;
        [change_view setTitle:@"Standard View" forState:UIControlStateNormal];
        mapView.mapType=MKMapTypeHybrid;
        
    }
}

-(void) updateRouteView:(NSString*)firstlat firstlon:(NSString*)firstlong secondlat:(NSString*)seconglat secondLon:(NSString*)secondLong{
    
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/directions/json?sensor=true&destination=%@%@%@&origin=%@%@%@",firstlat,@"%2C",firstlong,seconglat,@"%2C",secondLong]];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    NSURLResponse *response;
    NSError *error;
    
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    NSDictionary *dict1 = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
    
    if (!error)
    {
        NSArray *array = [dict1 allValues];
        NSLog(@"%@ %@",array,[dict1 description]);
    }
    
    //
    [self parseResponse:dict1];
}

- (void)parseResponse:(NSDictionary *)response {
    NSArray *routes = [response objectForKey:@"routes"];
    NSDictionary *route = [routes lastObject];
    
    if (route) {
        NSString *overviewPolyline = [[route objectForKey: @"overview_polyline"] objectForKey:@"points"];
        _path =[self decodePolyLine:overviewPolyline];
        
        NSLog(@"%@",_path);
    }
}

-(NSMutableArray *)decodePolyLine:(NSString *)encodedStr {
    NSMutableString *encoded = [[NSMutableString alloc] initWithCapacity:[encodedStr length]];
    [encoded appendString:encodedStr];
    [encoded replaceOccurrencesOfString:@"\\\\" withString:@"\\"
                                options:NSLiteralSearch
                                  range:NSMakeRange(0, [encoded length])];
    NSInteger len = [encoded length];
    NSInteger index = 0;
    // NSMutableArray *array = [[NSMutableArray alloc] init];
    NSInteger lat=0;
    NSInteger lng=0;
    while (index < len) {
        NSInteger b;
        NSInteger shift = 0;
        NSInteger result = 0;
        do {
            b = [encoded characterAtIndex:index++] - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);
        NSInteger dlat = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lat += dlat;
        shift = 0;
        result = 0;
        do {
            b = [encoded characterAtIndex:index++] - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);
        NSInteger dlng = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lng += dlng;
        NSNumber *latitude = [[NSNumber alloc] initWithFloat:lat * 1e-5];
        NSNumber *longitude = [[NSNumber alloc] initWithFloat:lng * 1e-5];
        NSLog(@"%@,%@",latitude,longitude);
        
        NSString *str=[NSString stringWithFormat:@"%@,%@",latitude,longitude];
        // CLLocation *location1 = [[CLLocation alloc] initWithLatitude:[latitude floatValue] longitude:[longitude floatValue]];
        [showTitle addObject:str];
    }
    
    NSLog(@"%@",showTitle);
    return showTitle;
}

- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id <MKOverlay>)overlay {
    //    MKPolylineView *polylineView = [[MKPolylineView alloc] initWithPolyline:overlay];
    //    polylineView.strokeColor = [UIColor redColor];
    //    polylineView.lineWidth = 1.0;
    //
    //    return polylineView;
    
    MKOverlayView* overlayView = nil;
	
	if(overlay == routeLine)
	{
		//if we have not yet created an overlay view for this overlay, create it now.
        
        routeLineView = [[MKPolylineView alloc] initWithPolyline:self.routeLine];
        routeLineView.lineWidth = 3;
        if([self.routeLine.title isEqualToString:@"typeA"])
        {
            routeLineView.fillColor = [UIColor colorWithRed:51/255.0 green:102/255.0 blue:0 alpha:1];
            routeLineView.strokeColor = [UIColor colorWithRed:51/255.0 green:102/255.0 blue:0 alpha:1];
        }else {
            
            routeLineView.fillColor = [UIColor redColor];
            routeLineView.strokeColor = [UIColor redColor];
        }
       [self HideView];		
		overlayView = routeLineView;
		
	}
	return overlayView;
}


- (IBAction)zoom_out:(id)sender
{
    MKCoordinateRegion region = self.mapView.region;
    region.span.latitudeDelta  = MIN(region.span.latitudeDelta  * 2.0, 180.0);
    region.span.longitudeDelta = MIN(region.span.longitudeDelta * 2.0, 180.0);
    [self.mapView setRegion:region animated:YES];
    
}
- (IBAction)zoom_in:(id)sender
{
    
    MKCoordinateRegion region = self.mapView.region;
    region.span.latitudeDelta /= 2.0;
    region.span.longitudeDelta /= 2.0;
    [self.mapView setRegion:region animated:YES];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
- (void)viewDidUnload
{
    
    [self setBus_stop_view:nil];
    [self setShowaddress_btn_name:nil];
    [self setBanner1:nil];
    [self setRefresh_btn:nil];
    [self setMap_Btn:nil];
    [self setBack_btn1:nil];
    [self setSign_off_btn:nil];
    
    
    [self setGeomapView:nil];
    [self setGeomapView:nil];
    [self setChange_view:nil];

    [self setMap_tab_showing:nil];
    [super viewDidUnload];
}


-(void) connectionDidFinishLoading:(NSURLConnection *)connection
{
    if ([loadingStops isEqualToString:@"no"])
    {
        xmlParser = [[NSXMLParser alloc] initWithData:busData];
        [back_btn1 setEnabled:YES];
        [sign_off_btn setEnabled:YES];
        [refresh_btn setEnabled:YES];
        [map_Btn setEnabled:YES];
        [showaddress_btn_name setEnabled:YES];
    }
    else
    {
        [back_btn1 setEnabled:YES];
        [sign_off_btn setEnabled:YES];
        [refresh_btn setEnabled:YES];
        [map_Btn setEnabled:YES];
        [showaddress_btn_name setEnabled:YES];

        xmlParser = [[NSXMLParser alloc] initWithData:webData];
    }
    
    [xmlParser setDelegate:self];
    [xmlParser setShouldResolveExternalEntities:YES];
    [xmlParser setShouldProcessNamespaces:YES];
    [xmlParser parse];
}
-(void) connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *) response
{
    // activityView.hidden = TRUE;
	if ([response isKindOfClass: [NSHTTPURLResponse class]])
	{
		int statusCode = [(NSHTTPURLResponse*) response statusCode];
        
		if(statusCode == 400 || statusCode == 401 || statusCode == 403 || statusCode == 404 || statusCode == 502 || statusCode == 503)
		{
			NSString *string = [[NSString alloc]initWithFormat:@"%i",statusCode];
            
            NSLog(@"%@",string);
			UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"No internet connectivity!"  message:@"Please try later" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
            
		}else if(statusCode==500){
            
            NSLog(@"Username or password is inCorrect");
        }
	}
	[webData setLength:0];
}

-(void) connection :(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    if ([loadingStops isEqualToString:@"no"])
    {
        [busData appendData:data];
    }
    else
    {
        [webData appendData:data];
    }

	
}

-(void) connection :(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    connection = nil;
    webData = nil;
    busData=nil;
    if ([loadingStops isEqualToString:@"no"])
    {
        ;
    }
    else
    {
        
    [back_btn1 setEnabled:YES];
    [sign_off_btn setEnabled:YES];
    [refresh_btn setEnabled:YES];
    [map_Btn setEnabled:YES];
    [showaddress_btn_name setEnabled:YES];
    
    }
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"No internet connectivity!"  message:@"Please try later" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    
}

- (NSCachedURLResponse *)connection:(NSURLConnection *)connection willCacheResponse:(NSCachedURLResponse *)cachedResponse {
    return nil;
}



@end
