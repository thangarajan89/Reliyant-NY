//
//  main.m
//  RootMap1
//
//  Created by K@ly@n on 08/09/13.
//  Copyright (c) 2013 Kalyan. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
