//
//  ViewController.m
//  RootMap1
//
//  Created by K@ly@n on 08/09/13.
//  Copyright (c) 2013 Kalyan. All rights reserved.
//

#import "ViewController.h"
#import "NextStopsViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "MBReachability.h"
@interface ViewController ()

@end

@implementation ViewController

@synthesize currentElement,row_num;
@synthesize webData;
bool firstTime;
- (void)viewDidLoad
{
    
    [super viewDidLoad];
    tblView.layer.cornerRadius=10;
    tbl_arr=[[NSMutableArray alloc]init];
    rt_id_num=[[NSMutableArray alloc]init];
    row_name=[[NSString alloc]init];
    row_num=[[NSString alloc]init];
    firstTime=YES;
    [searchBar setSearchFieldBackgroundImage:[UIImage imageNamed:@"searchbar"] forState:UIControlStateNormal];
    UITextField *searchField;
    for (UIView *subview in searchBar.subviews)
    {
        if ([subview isKindOfClass:[UITextField class]]) {
            searchField = (UITextField *)subview;
            break;
        }
    }
    UIView *searchIcon = searchField.leftView;
    if ([searchIcon isKindOfClass:[UIImageView class]]) {
       // NSLog(@"aye");
    }
    
    [[searchBar.subviews objectAtIndex:0] removeFromSuperview];
    [searchBar setBackgroundColor:[UIColor clearColor]];
    searchField.rightView = NULL;
    searchField.textColor=[UIColor blackColor];
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 20)];
    searchField.leftView = paddingView;
    //searchField.leftViewMode = UITextFieldViewModeNever;
    searchField.rightViewMode = UITextFieldViewModeAlways;
    [searchField setValue:[UIColor blackColor] forKeyPath:@"_placeholderLabel.textColor"];
    [searchField setFont:[UIFont fontWithName:@"HelveticaNeue-BoldItalic" size:16.f]];
    
    if([UIScreen mainScreen].bounds.size.height==568)
    {
        
        [tblView setFrame:CGRectMake(20,120,285,393)];
        [self.view addSubview:tblView];
        
    }
    
    if ([MBReachability hasConnectivity])
    {
       [self getdata];
//        NSString *path=[[NSBundle mainBundle]pathForResource:@"GetRoutes_new1" ofType:@"xml"];
//        NSURL *url=[NSURL fileURLWithPath:path];
//        NSData *data=[NSData dataWithContentsOfURL:url];
//        xmlParser = [[NSXMLParser alloc] initWithData:data];
//        [xmlParser setDelegate:self];
//        [xmlParser setShouldResolveExternalEntities:YES];
//        [xmlParser setShouldProcessNamespaces:YES];
//        [xmlParser parse];

    }
    else
    {
        alert3= [[UIAlertView alloc]initWithTitle:@"No internet connectivity!"  message:@"Please try later" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert3 show];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    row_num=@"";
    [searchBar resignFirstResponder];
    [self searchBarCancelButtonClicked:searchBar];
    [self updateSearchString:searchString];
    search_img.hidden=NO;
}

-(void)getdata
{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:@"http://otpstaging.timepointsoftware.com/api/MobileAPI/GetRoutesForToday?dbId=450.1"]];
    [request setHTTPMethod:@"GET"];
    [request setValue:@"application/xml;charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    
    NSString *accept = [NSString stringWithFormat:@"application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5"];
    
    [request addValue:accept forHTTPHeaderField: @"Accept"];
    
    NSURLConnection *conn = [NSURLConnection connectionWithRequest:request delegate:self];
    [conn start];
    if(conn)
        webData = [NSMutableData data];

}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDic
{
    currentElement = elementName;
}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if ([currentElement isEqualToString:@"RouteName"])
    {
        [tbl_arr addObject:string];
    }
    if ([currentElement isEqualToString:@"RouteId"])
    {
        //NSLog(@"%@",string);
        if(![rt_id_num containsObject:string])
        {
            [rt_id_num addObject:string];
        }
    
    }
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    [tblView reloadData];
}
- (void)parserDidEndDocument:(NSXMLParser *)parser{
    NSLog(@"%@ %@",rt_id_num,tbl_arr);
    
}
-(void)viewDidAppear:(BOOL)animated
{
    [tblView reloadData];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([[self filterContactsWithLastName:searchString]count]==0)
    {
        return 1;
    }
    else
    {
        return [[self filterContactsWithLastName:searchString]count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    NSString *str;
    
    
    if ([[self filterContactsWithLastName:searchString]count]==0)
    {
        if (firstTime)
           str= @"Loading....";
        else
           str= @"No Records Found";
        
         cell.backgroundView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"route-btn1.png"]];
    }
    else
    {
        str= [[self filterContactsWithLastName:searchString]objectAtIndex:indexPath.row];
        cell.backgroundView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"route-btn.png"]];
        firstTime=NO;
    }
    cell.textLabel.text=str;
    cell.textLabel.backgroundColor=[UIColor clearColor];
    UIView *view=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    view.backgroundColor=[UIColor clearColor];
    cell.selectedBackgroundView=view;


    return cell;

}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 44;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame=CGRectMake(0, 0, 320, 44);
   
    [btn setTitle:@"(Please Select a Route)               " forState:UIControlStateNormal];
    [btn setUserInteractionEnabled:NO];
    
    [btn setBackgroundImage:[UIImage imageNamed:@"route-btn1.png"] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    return btn;
}
// Called after the user changes the selection.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NextStopsViewController *next=[[NextStopsViewController alloc]initWithNibName:@"NextStopsViewController" bundle:nil];

    
    if ([[self filterContactsWithLastName:searchString]count]==0)
    {
        ;
    }
    else
    {
        NSString *rootName=[[self filterContactsWithLastName:searchString]objectAtIndex:indexPath.row];
        next.rootName=rootName;
        int index=[tbl_arr indexOfObject:rootName];
        
        NSLog(@"%@", [rt_id_num objectAtIndex:index]);
        next.rootID=[rt_id_num objectAtIndex:index];
        
        [self.navigationController pushViewController:next animated:YES];
        
        [searchBar resignFirstResponder];
        [self searchBarCancelButtonClicked:searchBar];

    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.001;
}
//search optin implementation
- (void)searchBarTextDidBeginEditing:(UISearchBar *)asearchBar
{
    [asearchBar setShowsCancelButton:YES animated:YES];
    tblView.allowsSelection = NO;
    tblView.scrollEnabled = YES;
    search_img.hidden=YES;
  //  searchBar.showsCancelButton = NO;
}
- (void)searchBarTextDidEndEditing:(UISearchBar *)asearchBar{
    
    if (asearchBar.text.length>0) {
        ;
    }else{
        tblView.allowsSelection = YES;
        tblView.scrollEnabled = YES;
        [asearchBar setShowsCancelButton:NO animated:YES];
        [self updateSearchString:asearchBar.text];
    }   
}

-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    [searchDelayer invalidate], searchDelayer=nil;
    if (YES /* ...or whatever validity test you want to apply */)
    searchDelayer = [NSTimer scheduledTimerWithTimeInterval:0.02
                                                         target:self
                                                       selector:@selector(doDelayedSearch:)
                                                       userInfo:searchText
                                                        repeats:NO];
}

-(void)doDelayedSearch:(NSTimer *)t
{
    assert(t == searchDelayer);
    tblView.allowsSelection = YES;
    tblView.scrollEnabled = YES;
    [self updateSearchString:searchBar.text];

    searchDelayer = nil; // important because the timer is about to release and dealloc itself
}

-(NSArray*)filterContactsWithLastName:(NSString*)custName{
    
    NSString *search = [custName stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceCharacterSet]];
    if (custName && custName.length > 0)
    {
        filterContacts = [[NSArray new]init];
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:
                                  @"(SELF BEGINSWITH[cd] %@)", search];
        //NSPredicate *predicate = [NSPredicate predicateWithFormat:@"custName LIKE %@", custName];
        filterContacts=[tbl_arr filteredArrayUsingPredicate:predicate];
        NSLog(@"filteredArray:%@",filterContacts);
        return filterContacts;
    }
    else
    {
        return tbl_arr;
        [searchBar resignFirstResponder];
    }
}

- (void)updateSearchString:(NSString*)aSearchString
{
    searchString = [[NSString alloc]initWithString:aSearchString];
    [tblView reloadData];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)asearchBar
{
    [asearchBar setShowsCancelButton:NO animated:YES];
    [asearchBar resignFirstResponder];
    tblView.allowsSelection = YES;
    tblView.scrollEnabled = YES;
    asearchBar.text=@"";
     search_img.hidden=NO;
    
    [self updateSearchString:searchBar.text];
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)asearchBar
{
    tblView.allowsSelection = YES;
    tblView.scrollEnabled = YES;
    [self updateSearchString:searchBar.text];
}
- (IBAction)exit_btn:(id)sender
{
    alert2=[[UIAlertView alloc]initWithTitle:Nil message:@"Are you sure to exit?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
    [alert2 show];
    
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView == alert2)
    {
        if (buttonIndex == 0)
        {
            ;
        }
        else
        {
            exit(0);
        }
    }
    if(alertView == alert3)
    {
        if (buttonIndex == 0)
        {
           // [self ntwrkchecking];
        }
    }
}
- (void)viewDidUnload
{
    search_img = nil;
    [super viewDidUnload];
}

-(void) connectionDidFinishLoading:(NSURLConnection *)connection
{
    xmlParser = [[NSXMLParser alloc] initWithData:webData];
    [xmlParser setDelegate:self];
    [xmlParser setShouldResolveExternalEntities:YES];
    [xmlParser setShouldProcessNamespaces:YES];
    [xmlParser parse];
}
-(void) connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *) response
{
    
   // Start_time = [NSDate timeIntervalSinceReferenceDate];
    // activityView.hidden = TRUE;
	if ([response isKindOfClass: [NSHTTPURLResponse class]])
	{
		int statusCode = [(NSHTTPURLResponse*) response statusCode];
        
		if(statusCode == 400 || statusCode == 401 || statusCode == 403 || statusCode == 404 || statusCode == 502 || statusCode == 503)
		{
			NSString *string = [[NSString alloc]initWithFormat:@"%i",statusCode];
            
            NSLog(@"%@",string);
			UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"No internet connectivity!"  message:@"Please try later" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
            
		}else if(statusCode==500){
            //            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Login Failed"  message:@"Please check your username and password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            //            [alert show];
            NSLog(@"Username or password is inCorrect");
        }
	}
	[webData setLength:0];
}

-(void) connection :(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	[webData appendData:data];
}

-(void) connection :(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    connection = nil;
    webData = nil;
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"No internet connectivity!"  message:@"Please try later" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    
}

- (NSCachedURLResponse *)connection:(NSURLConnection *)connection willCacheResponse:(NSCachedURLResponse *)cachedResponse {
    return nil;
}


@end
