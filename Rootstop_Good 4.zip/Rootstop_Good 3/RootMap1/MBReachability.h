//
//  MBReachability.h
//  iPad_Mathrubhumi_19Feb2012
//
//  Created by M S Gopal on 27/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sys/socket.h>
#import <netinet/in.h>
#import <SystemConfiguration/SystemConfiguration.h>

@interface MBReachability : NSObject
+(BOOL)hasConnectivity;
@end
