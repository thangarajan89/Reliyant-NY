//
//  NextStopsViewController.h
//  RootMap1
//
//  Created by K@ly@n on 08/09/13.
//  Copyright (c) 2013 Kalyan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import<MapKit/MapKit.h>
@class CLLocationManager;

@interface NextStopsViewController : UIViewController<NSXMLParserDelegate,MKMapViewDelegate,CLLocationManagerDelegate>
{
    NSXMLParser *xmlParser;
    NSString *currentElement;
    
    NSMutableArray *NextStop_arr;
    NSMutableArray *Time_arr;
    NSMutableArray *Time2_arr;
    
    NSMutableArray *est_status_arr1;
    NSMutableArray *est_status_arr2;
    

    
    NSMutableArray *VehicleId_arr;
    NSMutableArray *Direction_arr;
    NSMutableArray *DirectionId_arr;
    
    IBOutlet UITableView *tablView;
    
    ViewController *route_page;
    NSString *route_pass;
    
    IBOutlet UIActivityIndicatorView *act;
     UIAlertView *alert1;
     UIAlertView *alert2;
     UIAlertView *alert3;
     UIAlertView *alert5;
     UIAlertView * alert_NoRecords;
     NSString *new_string;
    
    IBOutlet UIButton *back_btn;
    
    NSMutableArray *stopClose_arr;
    NSMutableDictionary *dict;
    NSMutableArray *TripDirection_arr;
    NSMutableArray *TripDirectionId_arr;
    NSMutableArray *TripLatt_arr;
    NSMutableArray *TripLon_arr;
    NSMutableArray *TripMDCid_arr;
    NSMutableArray *TripTitle_arr;
    

    IBOutlet UIView *maplet;
    NSMutableArray *LastLatitude_arr;
    NSMutableArray *LastLongitude_arr;
    
	NextStopsViewController *NSVC;
	IBOutlet MKMapView* mapView;
    
    NSMutableArray *UnComl_title;
    NSMutableArray *UnComl_lat;
    NSMutableArray *UnComl_lon;
    
    NSMutableArray *showTitle;
    
    MKMapPoint * pointsArray;
    NSMutableArray* annotations;
    NSMutableArray *_path;
    
    MKMapRect _routeRect;
    MKPolylineView *routeLineView;
    NSArray *direction;
    
    NSString *loadingStops;
    int ScreenWidth;
    int ScreenHeight;
    
    //InterAction Objects
    UIView *InterActionview;

}
@property (nonatomic, retain) NSMutableArray *Status_arr;

@property (strong, nonatomic) IBOutlet UIButton *back_btn1;
@property (strong, nonatomic) IBOutlet UIButton *sign_off_btn;

@property (strong, nonatomic) IBOutlet UIButton *refresh_btn;
- (IBAction)refresh_btn:(id)sender;

- (IBAction)bus_stop_btn:(id)sender;
- (IBAction)exit_btn:(id)sender;
- (IBAction)map_Btn:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *map_Btn;


@property (strong, nonatomic) IBOutlet UIButton *showaddress_btn_name;
@property (weak, nonatomic) IBOutlet UIView *bus_stop_view;

@property (nonatomic, retain) NSMutableArray *lat_ary;
@property (nonatomic, retain) NSMutableArray *long_ary;
@property (nonatomic, retain) NSMutableArray *cords_array;

@property (nonatomic,retain) NSString *rootName;
@property (nonatomic, retain) NSString* rootID;

@property (strong, nonatomic) IBOutlet UIImageView *banner1;
@property(nonatomic,retain)NSMutableData *webData;
@property(nonatomic,retain)NSMutableData *busData;

//@property (nonatomic,copy) NSString *;
@property (nonatomic, copy) NSString *BusId;
@property (nonatomic, copy) NSString *BusId1;


@property(nonatomic,retain) MKPolyline *routeLine;
@property(nonatomic,retain) MKPolyline *RedrouteLine;



@property (strong, nonatomic) IBOutlet UIView *map_tab_showing;


@property(nonatomic,retain)	IBOutlet MKMapView* mapView;

@property (retain, nonatomic) MKMapView *geomapView;
@property (retain, nonatomic) NSMutableArray *cords_lat;
@property (retain, nonatomic) NSMutableArray *cords_long;
@property (retain, nonatomic) NSMutableArray *title_ary;
@property (retain, nonatomic) NSMutableArray *depo_status;
//@property (retain, nonatomic) NSMutableDictionary *Alldict;
@property (retain, nonatomic) NSString *bus_num;


@property (retain, nonatomic) NSMutableArray *dir_ary;


@property (retain, nonatomic) IBOutlet UIButton *change_view;
- (IBAction)change_view:(id)sender;
- (IBAction)zoom_out:(id)sender;
- (IBAction)zoom_in:(id)sender;
-(IBAction)Back:(id)sender;


@end
