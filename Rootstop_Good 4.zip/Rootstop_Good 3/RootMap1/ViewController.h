//
//  ViewController.h
//  RootMap1
//
//  Created by K@ly@n on 08/09/13.
//  Copyright (c) 2013 Kalyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSXMLParserDelegate>
{
    NSXMLParser *xmlParser;
    UIImage *cellBackGround;
    NSString *currentElement;
    NSString *searchString;
    NSString *row_name;
    NSArray *filterContacts;
    NSTimer *searchDelayer;
    NSMutableArray *tbl_arr;
    NSMutableArray *rt_id_num;
    UIAlertView *alert2;
    
    IBOutlet UISearchBar *searchBar;
    IBOutlet UITableView *tblView;
    IBOutlet UIButton *search_img;
    UIAlertView *alert3;
    
    NSTimeInterval *Start_time;
    NSTimeInterval *End_time;
    
}

@property(nonatomic,retain) NSString *currentElement;
@property(nonatomic,retain) NSString *row_num;

@property(nonatomic,retain)NSMutableData *webData;
-(void)getdata;



@end
